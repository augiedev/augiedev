// $(document).ready(function() {
//   var cartHead = $('#secondary-nav h3 a').text();
//   $('#secondary-nav a:not(".active")').html('<span>' + cartHead + '</span>');
// });